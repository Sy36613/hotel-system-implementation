<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href = "style.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <h1>Hotel Front Desk System(special action)</h1>
    <?php include "navigator.php" ?>
    <br>
    <br>
        <nav>
        <card>find the record that customer paid by cash <a href="selection.php">[view]</a></card> <br><br>
        <card>find the record that customer check in August <a href="selection1.php">[view]</a></card> <br><br>
        </nav>
     



   
    

</body>
<br><br>
<a href="index.php">Home</a>
</html>