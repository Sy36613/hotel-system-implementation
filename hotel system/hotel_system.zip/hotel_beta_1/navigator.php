<nav>  
    <a href="view.php">VIEW</a>  &ensp;|&ensp;
    <a href="insert.php">INSERT</a>  &ensp;|&ensp;
    <a href="edit.php">EDIT</a>  &ensp;|&ensp;
    <a href="special.php">SPECIAL</a> 
</nav>

