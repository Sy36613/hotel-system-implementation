<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href = "style.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <h1>Hotel Front Desk System(special action)</h1>
    <?php include "navigator.php" ?>
    <br>
    <br>
        <nav>
        <card>find the customer checkin in number and their name <a href="projection.php">[view]</a></card> <br><br>
        <card>find the customer checkin in number and their paymentMethod <a href="projection1.php">[view]</a></card> <br><br>
        <card>find the customer checkin in number and checkInDeskNum <a href="projection2.php">[view]</a></card> <br><br>
        </nav>
     



   
    

</body>
<br><br>
<a href="index.php">Home</a>
</html>