<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href = "style.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <h1>Hotel Front Desk System(special action)</h1>
    <?php include "navigator.php" ?>
    <br>
    <br>
        <nav>
        <card> <a href="selectionChoice.php">[selection]</a></card> <br><br>
        <card> <a href="projectionChoice.php">[projection]</a></card> <br><br>
        <card>show the height of the buildings where each front_dest located <a href="join.php">[join]</a></card> <br><br>
        <card>find the record of the most expensive room <a href="aggregation.php">[aggregation]</a></card> <br><br>
        <card>find the most popular building( with the most customers check in) <a href="nested.php">[nested]</a></card> <br><br>
        <card>find the customer who visited all the amenities <a href="division.php">[division]</a></card>
        </nav>
     



   
    

</body>
<br><br>
<a href="index.php">Home</a>
</html>